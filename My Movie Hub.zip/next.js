// Sample data for movies, sports, and TV shows
const data = {
    movies: [
        { title: 'Inception', image: 'inception.jpeg', description: 'Title: Inception, Director: Christopher Nolan, Producer: Emma Thomas, Christopher Nolan, Release Date: July 16, 2010, Genre: Science Fiction, Action, Thriller, Running Time: 148 minutes, Production Companies: Warner Bros. Pictures, Legendary Pictures, Syncopy' },
        { title: 'The Matrix', image: 'matrix.jpeg', description: 'Title: The Matrix, Director: The Wachowskis (Lana and Lilly Wachowski), Producers: Joel Silver, Larry Wachowski, Andy Wachowski, Release Date: March 31, 1999, Genre: Science Fiction, Action, Cyberpunk, Running Time: 136 minutes ,Production Companies: Warner Bros. Pictures, Village Roadshow Pictures, Silver Pictures' },
        { title: 'Pushpa 2 - The Rule', image: 'pushpa2.jpeg', description: 'Title: Pushpa 2: The Rule, Director: Sukumar, Producer: Mythri Movie Makers, Release Date: Expected in 2024 (tentative), Genre: Action, Drama, Thriller, Language: Telugu (with potential dubbed versions in other languages), Production Companies: Mythri Movie Makers, Muttamsetty Media' },
        { title: 'Jumanji', image: 'jumanji.jpeg', description: 'Title: Jumanji: The Next Level, Director: Jake Kasdan, Producer: Matt Tolmach, William Teitler, Dwayne Johnson, Jake Kasdan, Release Date: December 13, 2019, Genre: Adventure, Action, Fantasy, Comedy, Production Companies: Columbia Pictures, Seven Bucks Productions, Matt Tolmach Productions.' },
        { title: 'Gravity', image: 'gravity.jpeg', description: 'Title: Gravity, Director: Alfonso Cuarón, Producer: Alfonso Cuarón, David Heyman, Screenwriter: Alfonso Cuarón, Release Date: October 4, 2013, Genre: Sci-Fi, Thriller, Drama, Production Companies: Warner Bros. Pictures, Heyday Films, Esperanto Filmoj.' },
        { title: 'The Nun', image: 'the nun.jpeg', description: 'Title: The Nun, Director: Corin Hardy, Producer: James Wan, Peter Safran, Screenwriter: Gary Dauberman, James Wan, Release Date: September 7, 2018, Genre: Horror, Mystery, Thriller, Production Companies: Warner Bros. Pictures, New Line Cinema, Atomic Monster Productions, The Safran Company.' },
        { title: 'Sikandar ka Muqaddar', image: 'SKM.jpeg', description: 'Title: Sikandar Ka Muqaddar, Director: Rakesh Kumar, Producer: Rakesh Kumar, Screenwriter: Rakesh Kumar, Release Date: 1988, Genre: Action, Drama, Production Companies: R.K. Productions.' },
        { title: 'Lucky bhaskar', image: 'LB.jpeg', description: 'Title: Lucky Bhaskar, Director: Rajeev Kumar, Producer: K. C. Bokadia, Screenwriter: K. C. Bokadia, Release Date: 1999, Genre: Comedy, Drama, Production Companies: B. R. Films.' },
        { title: 'Devara - Part 1', image: 'devara.jpeg', description: 'Title: Devara, Director: Koratala Siva, Producer: NTR Arts, Yuvasudha Arts, Screenwriter: Koratala Siva, Release Date: 2024, Genre: Action, Drama, Production Companies: NTR Arts, Yuvasudha Arts.' },
        { title: 'Bhool bhulaiyaa 3', image: 'BB3.jpeg', description: 'Title: Bhool Bhulaiyaa 3, Director: Anees Bazmee, Producer: Bhushan Kumar, Krishan Kumar, Murad Khetani, Screenwriter: Aakash Kaushik, Release Date: 2024, Genre: Comedy, Horror, Thriller, Production Companies: T-Series, Cine1 Studios.' },
        { title: 'Blink', image: 'blink.jpeg', description: 'Apoorva hides his failed MA from his mother in Bengaluru. Working odd jobs and relying on Swapna, his ability to control blinking becomes a curse when an old man says his father lives, Director: Bengaluru Srinidhi, Writer: Bengaluru Srinidhi, Stars: Chaithra J. AcharSuresh AnagalliRavi aneka' },
        { title: 'Singham Again', image: 'S.jpeg', description: 'Title: Singham Again, Director: Rohit Shetty, Producer: Rohit Shetty, Ajay Devgn, Screenwriter: Sajid-Farhad, Release Date: 2024, Genre: Action, Drama, Thriller, Production Companies: Rohit Shetty Picturez, Reliance Entertainment, Ajay Devgn FFilms.' },
        { title: 'Vettaiyan', image: 'V.jpeg', description: 'Title: Vettaiyan, Director: A. Venkatesh, Producer: T. S. S. Murthi, Screenwriter: A. Venkatesh, Release Date: 2024, Genre: Action, Drama, Production Companies: T.S.S. Films.' },
        { title: 'Venom The Last Dance', image: 'Venom.jpeg', description: 'Title: Venom: The Last Dance, Director: Andy Serkis, Producer: Amy Pascal, Avi Arad, Matt Tolmach, Screenwriter: Kelly Marcel, Release Date: 2024 (upcoming), Genre: Action, Sci-Fi, Superhero, Production Companies: Columbia Pictures, Marvel Entertainment, Pascal Pictures.' },
        { title: 'Deadpool x Wolverine', image: 'D.jpeg', description: 'Title: Deadpool 3 (Deadpool X Wolverine), Director: Shawn Levy, Producer: Ryan Reynolds, Kevin Feige, Simon Kinberg, Screenwriter: Rhett Reese, Paul Wernick, Zeb Wells, Release Date: 2024, Genre: Action, Comedy, Superhero, Production Companies: 20th Century Studios, Marvel Studios, Reynolds’ production company (Maximum Effort).' },
        { title: 'Antrum', image: 'ANt.jpeg', description: 'Title: Antrum, Director: David Amito, Michael Laicini, Producer: David Amito, Michael Laicini, Screenwriter: David Amito, Michael Laicini, Release Date: 2018, Genre: Horror, Mystery, Drama, Production Companies: Dark Star Pictures, Artsploitation Films.' },
        { title: 'Furiosa a mad max saga ', image: 'MAD.jpeg', description: 'Title: Furiosa, Director: George Miller, Producer: George Miller, Doug Mitchell, Screenwriter: George Miller, Nico Lathouris, Release Date: 2024 (upcoming), Genre: Action, Adventure, Sci-Fi, Production Companies: Warner Bros. Pictures, Village Roadshow Pictures, Kennedy Miller Mitchell.' },
        { title: 'The Strangers Chapter - 1', image: 'ST.jpeg', description: 'Title: The Strangers: Chapter 1, Director: Johannes Roberts, Producer: Courtney Solomon, Mark Canton, Screenwriter: Johannes Roberts, Release Date: 2024 (upcoming), Genre: Horror, Thriller, Production Companies: Aviron Pictures, Solstice Studios, Constantin Film.' },
        { title: 'Outside', image: 'out.jpeg', description: 'Amidst a barren world void of human life, one man confronts his past in search of closure. Directors: Carlo LedesmaFrank van Bergen, Writers: Carlo LedesmaFrank van Bergen, Stars: Matthijs de KoningSid LuceroErwin Beltz' },
        { title: 'Tarot', image: 'tarot.jpeg', description: 'When a group of friends recklessly violates the sacred rule of Tarot readings, they unknowingly unleash an unspeakable evil trapped within the cursed cards. One by one, they come face to face with fate and end up in a race against death. Directors: Spenser CohenAnna Halberg, Writers: Spenser CohenAnna HalbergNicholas Adams, Stars: Harriet SlaterAdain BradleyJacob Batalon' },
        { title: 'Sector 36', image: 'secto.jpeg', description: 'A fictional story Inspired by true events, several children go missing from a basti (slum) in Sector 36. A determined police officer must now face off with a cunning serial killer as a chilling investigation and dark secrets unfold. Director: Aditya Nimbalkar, Writer: Bodhayan Roychaudhury, Stars: Vikrant MasseyDeepak DobriyalAkash Khurana' },
        { title: 'Greenland', image: 'green.jpeg', description: 'Title: Greenland, Director: Ric Roman Waugh, Producer: Basil Iwanyk, Erik Feig, Screenwriter: Chris Sparling, Release Date: 2020 (original release), Genre: Action, Drama, Thriller, Production Companies: STX Entertainment, Thunder Road Pictures, 3 Arts Entertainment.' },
        { title: 'Kandahar', image: 'kand.jpeg', description: 'Title: Kandahar, Director: Ric Roman Waugh, Producer: Gerard Butler, Basil Iwanyk, Screenwriter: Mitchell LaFortune, Release Date: 2023, Genre: Action, Thriller, Production Companies: Thunder Road Pictures, G-Base, and Millennium Media.' },
        { title: 'Mechanic Resurrection', image: 'mech.jpeg', description: 'Title: Mechanic: Resurrection, Director: Dennis Gansel, Producer: Jason Statham, William Chartoff, David Winkler, Screenwriter: Philip Shelby, Tony Mosher, Release Date: August 26, 2016, Genre: Action, Thriller, Production Companies: Lionsgate, Millennium Films, Chartoff-Winkler Productions.' },
        { title: 'The Beekeeper', image: 'bee.jpeg', description: 'Title: The Beekeeper, Director: David Ayer, Producer: John Logan, David Ayer, Screenwriter: John Logan, Release Date: 2023, Genre: Action, Thriller, Production Companies: 87North Productions, Miramax Films, and StudioCanal.' }
    ],
    sports: [
        { title: 'Champions League', image: 'cl.png', description: 'The UEFA Champions League (UCL) is one of the most prestigious annual football tournaments in the world, organized by the Union of European Football Associations (UEFA)' },
        { title: 'NBA Finals', image: 'nba.jpeg', description: 'The NBA (National Basketball Association) is a professional basketball league in the United States and one of the most popular sports leagues globally. Known for its high-energy games and iconic players, the NBA features 30 teams competing for the championship title each season.' },
        { title: 'Fantasy Sports', image: 'FS.png', description: 'Fantasy Sports is a type of online gaming where participants build virtual teams of real-life athletes from various sports, such as football, cricket, basketball, or baseball. Points are scored based on the real-world performance of the selected players during actual games.' },
        { title: 'Top Records Broken This Year', image: 'JSS.jpeg', description: 'Top Records Broken This Year refers to significant achievements in sports where athletes or teams surpass historical benchmarks, setting new milestones in their respective fields. These records showcase extraordinary performances, talent, and dedication.' },
        { title: 'Football', image: 'foot.png', description: 'Football (also known as soccer) is a globally popular team sport where two teams of 11 players compete to score goals by moving a ball into the opposing team' },
        { title: 'Cricket', image: 'cric.png', description: 'Cricket is a bat-and-ball sport played between two teams of 11 players each. Originating in England, it is now one of the most popular sports globally, particularly in countries like India, Australia, England, Pakistan, and the West Indies.' },
        { title: 'Basketball', image: 'bass.jpeg', description: 'Basketball is a fast-paced team sport where two teams of five players each compete to score points by shooting a ball through the opposing team' },
        { title: 'Tennis', image: 'teen.png', description: 'Tennis is a racquet sport played between two players (singles) or two pairs of players (doubles). The game is played on a rectangular court, divided by a net, with the objective of hitting the ball over the net and into the opponent' },
        { title: 'Formula 1', image: 'f1.png', description: 'Formula 1 (F1) is the highest class of single-seater auto racing, governed by the Fédération Internationale de' },
        { title: 'Esports', image: 'espo.png', description: 'Esports (electronic sports) refers to competitive, organized video gaming where players or teams compete against each other in popular games like League of Legends, Dota 2, Counter-Strike: Global Offensive, Fortnite, and Overwatch.' },
        { title: 'Golf', image: 'golf.png', description: 'Golf is a sport where players use clubs to hit a ball into a series of holes on a course in as few strokes as possible. The game is typically played over 18 holes, with each hole having a unique layout and varying lengths. The objective is to complete the course with the lowest score, and each stroke counts as one point.' },
        { title: 'Athletics', image: 'athle.jpeg', description: 'Athletics is a collection of sports that include running, jumping, throwing, and walking events, and is often regarded as the foundation of all sports. It encompasses various disciplines such as track and field, road running, cross country, and race walking. ' },
        { title: 'Women in Sports', image: 'women.png', description: 'Women in sports refers to the participation and representation of female athletes in various sports disciplines at both amateur and professional levels. Over the past few decades, there has been significant progress in promoting gender equality and empowering women through sports. ' },
        { title: 'Mental Health Awareness in Sports', image: 'mental.png', description: 'Mental Health Awareness in Sports refers to recognizing and addressing the psychological well-being of athletes. It involves promoting open discussions about mental health challenges such as stress, anxiety, depression, and burnout, which can affect players at all levels of competition.' },
        { title: 'Biggest Controversies or Scandals', image: 'bigest.png', description: 'Biggest Controversies or Scandals in sports refer to major incidents or issues that have caused significant public and media attention, often involving unethical behavior, corruption, or rule violations. These controversies can impact the reputation of athletes, teams, and sports organizations. ' },
        { title: 'Sports Legends Retiring', image: 'legend.png', description: 'Sports legends retiring refers to the moment when highly accomplished and iconic athletes decide to end their professional careers. These retirements often mark the conclusion of a chapter in sports history and can evoke strong emotions among fans and fellow athletes. ' },
        { title: 'Technology in Sports', image: 'tech.jpeg', description: 'Technology in sports refers to the use of advanced tools and innovations to enhance the performance, safety, and experience of athletes, teams, and fans. It has become an integral part of modern sports, revolutionizing the way games are played, analyzed, and consumed. ' },
        { title: 'Upcoming Major Events', image: 'up.jpeg', description: 'Upcoming major sports events to look forward to include the 2024 Summer Olympics in Paris, set for July 26 to August 11, 2024, where athletes from around the world will compete in a variety of sports. The UEFA Euro 2024 will take place in Germany from June 14 to July 14, 2024, featuring top national football teams battling for European supremacy. ' },
        { title: 'FIFA World Cup', image: 'fifa.jpeg', description: 'The FIFA World Cup is the premier international football (soccer) tournament, organized by the Fédération Internationale de Football Association (FIFA). It takes place every four years and features national teams from around the world competing for the title of world champion. ' },
        { title: 'Major Injuries', image: 'major.jpeg', description: 'Major injuries in sports refer to significant physical setbacks that can affect an athlete’s career and performance. These injuries often result in long recovery periods, surgeries, and sometimes permanent changes to an athlete' },
        { title: 'Top 10 Highlights of the Week', image: 'highlight.jpeg', description: 'This week in sports was filled with thrilling moments and significant achievements. Lionel Messi marked a milestone by scoring his 1,000th career goal in an international friendly, reinforcing his legacy as one of the greatest football players of all time. ' },
        { title: 'Live Match Updates', image: 'update.png', description: 'Live match updates refer to real-time information and scores from ongoing sports events. These updates typically include details such as scores, key plays, player statistics, and other significant moments during the match. They can be accessed through various platforms, including sports websites, apps, social media, and live broadcasts.' },
        { title: 'Olympics', image: 'olym.png', description: 'The Olympics is a major international multi-sport event featuring summer and winter sports competitions. It is organized by the International Olympic Committee (IOC) and is held every four years, with the Summer and Winter Games alternating every two years. ' },
        { title: 'VAR in football', image: 'VAR.jpeg', description: 'VAR (Video Assistant Referee) is a technology used in football (soccer) to assist referees in making more accurate decisions during matches. Introduced to help reduce human error, VAR is designed to review certain situations where clear mistakes might have been made. ' },
        { title: 'Rising Stars', image: 'stars.jpeg', description: 'Rising stars in sports are young and talented athletes who are quickly gaining recognition for their exceptional skills and potential to become future legends in their respective sports. These athletes often make their mark by breaking records, showcasing impressive performances, and consistently outperforming expectations. ' }
    ],
    tvShows: [
        { title: 'Breaking Bad', image: 'BBBB.jpeg', description: 'The story of a high school chemistry teacher turned meth manufacturer.' },
        { title: 'Stranger Things', image: 'SS.jpeg', description: '' },
        { title: 'Chernobyl', image: 'CC.jpeg', description: '' },
        { title: 'Lost', image: 'lost.jpeg', description: '' },
        { title: 'Mirzapur 3', image: 'MIRZA.jpeg', description: '' },
        { title: 'Panchayat', image: 'pancha.jpeg', description: '' },
        { title: 'The Boys', image: 'boys.jpeg', description: '' },
        { title: 'Under The Dome', image: 'UTD.jpeg', description: '' },
        { title: 'The Legend of Hanuman', image: 'hanuman.jpeg', description: '' },
        { title: 'Hostel Daze', image: 'HD.jpeg', description: '' },
        { title: 'The Witcher', image: 'TW.jpeg', description: '' },
        { title: 'Game of Thrones', image: 'GOT.jpeg', description: '' },
        { title: 'House of The Dragon', image: 'HOTD.jpeg', description: '' },
        { title: 'Citadel', image: 'cita.jpeg', description: '' },
        { title: 'Farzi', image: 'farzi.jpeg', description: '' },
        { title: 'From', image: 'from.jpeg', description: '' },
        { title: 'House of Secrets', image: 'HOS.jpeg', description: '' },
        { title: 'The Last Of Us', image: 'LOS.jpeg', description: '' },
        { title: 'Narcos', image: 'narcos.jpeg', description: '' },
        { title: 'Mumbai Diaries', image: 'MD.jpeg', description: '' },
        { title: 'The Signal', image: 'TS.jpeg', description: '' },
        { title: 'Flash', image: 'THEFLASH.jpeg', description: '' },
        { title: 'Dark', image: 'DRAK.jpeg', description: '' },
        { title: 'Money Heist', image: 'MH.jpeg', description: '' },
        { title: 'The Family Man', image: 'TFM.jpeg', description: '' },
    ],
    watchlist: [
        {title: 'Narcos', image: 'narcos.jpeg', description: 'Added to Wishlist!'},
        { title: 'Farzi', image: 'farzi.jpeg', description: 'Added to Wishlist!' },
        { title: 'From', image: 'from.jpeg', description: 'Added to Wishlist!' }
    ],
    downloads: []
};

// Display category content
function showCategory(category) {
    const contentContainer = document.getElementById('contentContainer');
    contentContainer.innerHTML = ''; // Clear existing content

    if (data[category].length > 0) {
        data[category].forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('content-item');
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.title}">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <button onclick="displayDetails('${item.title}', '${category}')">View Details</button>
            `;
            contentContainer.appendChild(itemElement);
        });
    } else {
        contentContainer.innerHTML = '<p>No content available.</p>';
    }
}

// Display search results
function searchContent() {
    const query = document.getElementById('searchBox').value.toLowerCase();
    const contentContainer = document.getElementById('contentContainer');
    contentContainer.innerHTML = '';

    Object.keys(data).forEach(category => {
        const results = data[category].filter(item => item.title.toLowerCase().includes(query));
        results.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('content-item');
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.title}">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <button onclick="displayDetails('${item.title}', '${category}')">View Details</button>
            `;
            contentContainer.appendChild(itemElement);
        });
    });
}

// Display details of an item when clicked
function displayDetails(title, category) {
    const contentContainer = document.getElementById('contentContainer');
    contentContainer.innerHTML = ''; // Clear existing content
    const item = data[category].find(item => item.title === title);
    if (item) {
        contentContainer.innerHTML = `
            <div class="content-item">
                <img src="${item.image}" alt="${item.title}">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <button onclick="showCategory('${category}')">Back to ${category}</button>
            </div>
        `;
    }
}

// Initial view setup
showCategory('movies');
