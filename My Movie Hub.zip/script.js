// Predefined credentials
const correctUsername = "admin"; // Change as needed
const correctPassword = "1234"; // Change as needed

function validateLogin() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("error-message");

    if (username === correctUsername && password === correctPassword) {
        // Redirect to index.html after successful login
        window.location.href = 'index.html';
    } else {
        errorMessage.textContent = "Invalid username or password. Please try again.";
    }
}
